'use strict';
// Results arrive from scripts running inside already-loaded pages.
// Store only URL and timestamp evidence (no HTML, credentials, cookies).
chrome.action.onClicked.addListener(async (tab) => {
  const url = chrome.runtime.getURL(`dashboard.html?windowId=${encodeURIComponent(tab.windowId)}`);
  await chrome.tabs.create({windowId:tab.windowId,url,active:true});
});
chrome.runtime.onMessage.addListener((request,sender,sendResponse)=>{
  if (request?.kind !== 'DATUMI_COLLECTED' || !sender?.tab?.id || !sender?.url) return;
  try {
    const u=new URL(sender.url);
    const domains=['facebook.com','instagram.com','tiktok.com','youtube.com','youtu.be','x.com','twitter.com'];
    if (!domains.some(d=>u.hostname===d || u.hostname.endsWith('.'+d)))return;
    const tabId=sender.tab.id, result=request.result;
    if(!result || typeof result!=='object')return;
    const key='tab_'+tabId;
    chrome.storage.session.set({[key]:{href:sender.url,result,at:Date.now()}}).catch(()=>{});
  }catch(e){}
});
chrome.tabs.onRemoved.addListener(tabId=>{chrome.storage.session.remove('tab_'+tabId).catch(()=>{});});
