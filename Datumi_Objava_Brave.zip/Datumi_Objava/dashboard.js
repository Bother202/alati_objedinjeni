'use strict';
/* Brave Datumi objava – sekvencijalni režim za verziju 5.0.
   Zamjenjuje SAMO dashboard.js. Ne čita cookies/lozinke, ne šalje podatke mrežom.
   Očitava samo stranice koje je korisnik otvorio u istom Brave prozoru. */
const $ = id => document.getElementById(id);
const SOURCE_WINDOW = Number(new URLSearchParams(location.search).get('windowId'));
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
let rows = [], working = false, stopped = false, canHover = false;
const MAX_LOAD_MS = 10500;    // page load (must not hang forever)
const MAX_READ_MS = 6300;    // post-hydration inspection
const STEP_MS = 500;

function platform(url) { return DateProbe.platform(url); }
function accepted(url) {
  try {
    const u = new URL(url), p = platform(url);
    if (p === 'Facebook') return /\/(posts|reels?|videos?|watch|permalink\.php|story\.php|photo|photos|groups)\b/.test(u.pathname);
    if (p === 'Instagram') return /\/(p|reels?|tv)\/[\w-]+/.test(u.pathname);
    if (p === 'YouTube') return u.hostname === 'youtu.be' || /\/(watch|shorts|live)\b/.test(u.pathname);
    if (p === 'TikTok') return /\/video\/\d+/.test(u.pathname);
    if (p === 'X') return /\/status\/\d+/.test(u.pathname);
  } catch (e) { /* invalid URL */ }
  return false;
}
function normalize(url) {
  try {
    const u = new URL(url);
    if (platform(url) === 'Facebook') {
      const m = u.pathname.match(/^\/reel\/(\d+)\/?$/);
      if (m) return `https://www.facebook.com/watch/?v=${m[1]}`;
    }
    if (platform(url) === 'Instagram') {
      const m = u.pathname.match(/^\/(?:reel|reels|tv)\/([\w-]+)\/?$/);
      if (m) return `https://www.instagram.com/p/${m[1]}/`;
    }
  } catch (e) { /* leave original */ }
  return url;
}
function status(message) { $('status').textContent = message; }
function shortError(error) { return String(error?.message || error || '').slice(0, 160); }
function deadline(promise, maxMs, fallback) {
  let timer;
  return Promise.race([
    promise,
    new Promise((_, reject) => { timer = setTimeout(() => reject(new Error(fallback)), maxMs); })
  ]).finally(() => clearTimeout(timer));
}
function isDirect(candidate) {
  return candidate && ['direct', 'id', 'manual'].includes(candidate.confidence);
}
function fmt(candidate) {
  if (!candidate || !Number.isFinite(candidate.ms)) return '';
  const parts = Object.fromEntries(new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Europe/Sarajevo', year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23'
  }).formatToParts(new Date(candidate.ms)).filter(p => p.type !== 'literal').map(p => [p.type, p.value]));
  // Always output an ISO-style, fixed-width local date-time so spreadsheet
  // programs can sort it lexicographically, including date-only candidates.
  // 00:00:00 is a SORTING PLACEHOLDER if the source lacks a publication hour;
  // it must never be misinterpreted as a confirmed publication time.
  const date = `${parts.year}-${parts.month}-${parts.day}`;
  return `${date} ${candidate.precision === 'date' ? '00:00:00' : `${parts.hour}:${parts.minute}:${parts.second}`}`;
}
function sorted() {
  const sign = $('sort').value === 'desc' ? -1 : 1;
  return [...rows].sort((a, b) => {
    if (!a.date && !b.date) return a.index - b.index;
    if (!a.date) return 1;
    if (!b.date) return -1;
    return sign * (a.date.ms - b.date.ms) || a.index - b.index;
  });
}
function elt(tag, content, className) {
  const el = document.createElement(tag);
  if (content != null) el.textContent = String(content);
  if (className) el.className = className;
  return el;
}
function displayNote(r){
  const segments=[];
  const selected=r.date;
  if(selected){
    if(r.userVerified)segments.push('Korisnik potvrdio datum pregledom objave');
    else if(r.userChoice)segments.push('Korisnik odabrao kandidata (nije potvrđen pregledom objave)');
    else if(selected.lowConfidence)segments.push('Automatska procjena — niska pouzdanost');
    else if(selected.confidence==='probable')segments.push('Automatski odabran vjerovatan datum');
    else if(selected.confidence==='estimate')segments.push('Procjena iz dostupnih podataka');
    else segments.push('Očitano sa stranice');
    if(selected.precision==='date')segments.push('Vrijeme objave nije dostupno; 00:00:00 je samo za sortiranje, nije potvrđeno vrijeme');
  }
  const number=r.options?.length||0;
  if(number>1)segments.push(`Pronađeno ${number} mogućih datuma`);
  if(!selected)segments.push('Datum nije utvrđen');
  // Diagnostics and technical errors belong in the notes, not in the date cell.
  const technical=(r.note||'').replace(/^Datum objave nije pouzdano očitan\s*[·]?\s*/,'').trim();
  if(technical && !/^Čeka obradu|^Očitano sa stranice/.test(technical))segments.push(technical);
  return [...new Set(segments)].join(' · ');
}
function render() {
  $('n-total').textContent = rows.length;
  $('n-direct').textContent = rows.filter(r => isDirect(r.date)).length;
  $('n-estimate').textContent = rows.filter(r => ['estimate','probable'].includes(r.date?.confidence)).length;
  $('n-missing').textContent = rows.filter(r => !r.date).length;
  const body = $('results'); body.replaceChildren();
  for (const r of sorted()) {
    const tr = elt('tr');
    const dateCell = elt('td');
    // ONLY a machine-sortable date or an empty cell — never status text.
    dateCell.append(elt('span', fmt(r.date), 'date-main'));
    const linkCell = elt('td'), anchor = elt('a', r.target, 'url');
    anchor.href = r.target; anchor.target = '_blank'; anchor.rel = 'noreferrer noopener';
    linkCell.append(anchor);
    const platformCell = elt('td', r.platform);
    const noteCell = elt('td', displayNote(r) || '—', 'note');
    const choices=(r.options||[]).filter(p=>Number.isFinite(p.ms));
    if(choices.length>1){
      const details=elt('details'); details.className='date-choices';
      const summary=elt('summary', `Pregledaj ${choices.length} datuma / promijeni odabir`);
      const selection=elt('select','', '');
      selection.setAttribute('aria-label','Mogući datumi objave');
      choices.forEach((p,i)=>{
        const opt=document.createElement('option');opt.value=String(i);
        opt.textContent=`${fmt(p)} · ${p.source||'Kandidat'}${p.lowConfidence?' (procjena)':''}`;
        if(p.ms===r.date?.ms)opt.selected=true;
        selection.append(opt);
      });
      const confirmation=elt('label');
      const verified=elt('input');verified.type='checkbox';
      confirmation.append(verified,elt('span',' Provjerio/la sam datum na samoj objavi'));
      const apply=elt('button','Odaberi ovaj datum','mini');apply.type='button';
      apply.onclick=()=>{
        const p=choices[Number(selection.value)];if(!p)return;
        const verifiedByUser=verified.checked;
        r.date={...p,confidence:verifiedByUser?'manual':(p.confidence==='ambiguous'?'estimate':p.confidence),
          source:verifiedByUser?'Korisnik potvrdio datum pregledom objave':(p.source||'Korisnički odabir kandidata'),
          lowConfidence:!verifiedByUser,autoSelected:false};
        r.userChoice=true;r.userVerified=verifiedByUser;render();
      };
      const reset=elt('button','Vrati automatski odabir','mini');reset.type='button';
      reset.onclick=()=>{r.date=r.autoDate?{...r.autoDate}:null;r.userChoice=false;r.userVerified=false;render();};
      details.append(summary,selection,confirmation,apply,reset);
      noteCell.append(details);
    }
    tr.append(dateCell,linkCell,platformCell,noteCell);body.append(tr);
  }
  if (!rows.length){
    const tr=elt('tr'),td=elt('td','Otvori objave u tabovima i pokreni analizu.','empty');
    td.colSpan=4;tr.append(td);body.append(tr);
  }
  for (const id of ['copy','csv2','csvfull']) $(id).disabled = !rows.length;
}
function setWorking(value) {
  working = value;
  $('scan').disabled = value;
  $('stop').disabled = !value;
  $('pulse').classList.toggle('running', value);
}
function reportReply(reply) {
  return reply?.ok && reply.result && typeof reply.result === 'object' ? reply.result : null;
}
async function readTab(id) {
  try {
    const response = await deadline(chrome.tabs.sendMessage(id, { kind: 'DATUMI_READ' }), 1450, 'Čitač se nije javio');
    return reportReply(response);
  } catch (e) { return null; }
}
async function waitForDocument(tabId, target) {
  const started = Date.now();
  // Chrome/Brave 'complete' means page loaded, NOT that Facebook content is hydrated.
  while (Date.now() - started < MAX_LOAD_MS && !stopped) {
    let tab;
    try { tab = await chrome.tabs.get(tabId); } catch (e) { return false; }
    if (tab.status === 'complete' && !tab.discarded) return true;
    await sleep(300);
  }
  return false;
}
async function hoverDate(r) {
  if (!canHover || r.platform !== 'Facebook' || stopped) return null;
  let attached = false;
  const debuggee = { tabId: r.id };
  try {
    // Only ask the already-running content script to scroll the timestamp into view.
    await deadline(chrome.tabs.sendMessage(r.id, { kind: 'DATUMI_SCROLL_HEADER' }), 1250, 'Nema zaglavlja').catch(() => null);
    await sleep(180);
    const points = await deadline(chrome.tabs.sendMessage(r.id, { kind: 'DATUMI_HOVER_POINTS' }), 1250, 'Nema koordinata');
    if (!points?.ok || !points.points?.length) return null;
    await deadline(chrome.debugger.attach(debuggee, '1.3'), 2300, 'Debugger nedostupan');
    attached = true;
    for (const p of points.points.slice(0, 2)) {
      if (stopped) return null;
      await chrome.debugger.sendCommand(debuggee, 'Input.dispatchMouseEvent', { type: 'mouseMoved', x: p.x, y: p.y });
      await sleep(650);
      const resp = await deadline(chrome.tabs.sendMessage(r.id, { kind: 'DATUMI_TOOLTIP', x: p.x, y: p.y }), 1400, 'Tooltip nije dostupan').catch(() => null);
      if (resp?.ok && resp.result?.best?.ms) return resp.result.best;
    }
  } catch (e) { r.hoverProblem = shortError(e); }
  finally {
    if (attached) await chrome.debugger.detach(debuggee).catch(() => {});
  }
  return null;
}
async function analyze(r) {
  const original = await chrome.tabs.get(r.id);
  try {
    // Critically: ONE active Facebook page at a time; other pages stay idle.
    if (r.target !== original.url) {
      await chrome.tabs.update(r.id, { active: true, url: r.target });
    } else {
      await chrome.tabs.update(r.id, { active: true });
      await chrome.tabs.reload(r.id);
    }
    const loaded = await waitForDocument(r.id, r.target);
    if (!loaded) r.note = 'Stranica se nije potpuno učitala u zadanom vremenu';
    // Content hydration may continue after status=complete. Read repeatedly,
    // but stop as soon as the timestamp is tied to the requested post.
    let best = null, inspection = null, gotReader = false;
    const start = Date.now();
    while (Date.now() - start < MAX_READ_MS && !stopped) {
      inspection = await readTab(r.id);
      if (inspection) {
        gotReader = true;
        if (inspection.best?.ms) {
          best = inspection.best;
          // With several uncertain candidates allow one short additional hydration pass.
          if (!best.lowConfidence || Date.now() - start > 1200) break;
        }
      }
      await sleep(STEP_MS);
    }
    if (inspection?.alternatives?.length) {
      r.options = inspection.alternatives.filter(p => Number.isFinite(p.ms));
      if (!best && r.options.length) {
        best = {...r.options[0],confidence:'estimate',lowConfidence:true,autoSelected:true,
          source:r.options[0].source||'Najvjerovatniji dostupni kandidat'};
      }
    }
    if ((!best || best.lowConfidence) && !stopped) {
      const hovered = await hoverDate(r);
      if (hovered) { best = hovered; r.note = 'Datum očitan prelaskom mišem'; r.options = [hovered,...(r.options||[]).filter(p=>p.ms!==hovered.ms)]; }
    }
    if (!best) {
      const estimated = DateProbe.decodedId(r.target);
      if (estimated?.ms) { best = estimated; r.note = 'Procjena nastanka iz ID-a; datum objave nije potvrđen'; }
    }
    if (best) {
      r.date = best;
      r.autoDate = {...best};
      r.userChoice = false;
      if ((r.options?.length||0)>1) r.note = `Automatski izabran kandidat iz ${r.options.length} pronađenih datuma`;
      if (inspection?.diagnostics?.length) r.note += (r.note?' · ':'') + inspection.diagnostics.slice(0,2).join(' · ');
      if (!r.note) r.note = best.source || 'Datum iz prikaza objave';
      if (best.precision === 'date') r.note += ' · Sat objavljivanja nije prikazan';
      if (best.confidence === 'probable') r.note += ' · Indikacija, nije konačno potvrđeno';
    } else if (gotReader) {
      const note = inspection?.diagnostics?.filter(Boolean).slice(0, 2).join(' · ');
      r.note = `Datum objave nije pouzdano očitan${note ? ' · ' + note : ''}`;
      if (r.hoverProblem) r.note += ' · Hover: ' + r.hoverProblem;
    } else {
      r.note = 'Facebook nije učitao čitač stranice; pokušaj s manje otvorenih tabova';
    }
  } catch (e) {
    r.note = 'Neuspjela obrada: ' + shortError(e);
  }
}
async function run() {
  if (working) return;
  stopped = false;
  let originalDashboardTab = null;
  try {
    // Ask permission synchronously during the user's click; awaiting another API
    // first may consume Chromium's transient user activation.
    const hoverPermission = $('auto-hover').checked
      ? chrome.permissions.request({ permissions: ['debugger'] }).catch(() => false)
      : Promise.resolve(false);
    originalDashboardTab = await chrome.tabs.getCurrent();
    canHover = await hoverPermission;
    if (!Number.isInteger(SOURCE_WINDOW) || SOURCE_WINDOW <= 0) {
      status('Ne mogu prepoznati prozor. Zatvori ovaj pregled i ponovo klikni ikonu ekstenzije.');
      return;
    }
    const tabs = await chrome.tabs.query({ windowId: SOURCE_WINDOW });
    const uniq = new Set();
    rows = [];
    for (const tab of tabs) {
      if (!tab.url || !accepted(tab.url)) continue;
      const target = normalize(tab.url);
      if (uniq.has(target)) continue;
      uniq.add(target);
      rows.push({ id: tab.id, index: rows.length, original: tab.url, target,
        platform: platform(tab.url), date: null, note: 'Čeka obradu' });
    }
    if (!rows.length) { status('U ovom prozoru nema podržanih objava.'); render(); return; }
    setWorking(true);
    render();
    let i = 0;
    for (const r of rows) {
      if (stopped) break;
      status(`Analiziram ${i + 1}/${rows.length}: ${r.platform} (jedan tab u jednom trenutku)`);
      $('progress').textContent = `${i + 1}/${rows.length}`;
      await analyze(r);
      i++;
      render();
    }
    status(stopped ? `Prekinuto nakon ${i} objava. Rezultati su sačuvani u tabeli.` :
      `Završeno: ${rows.filter(r => !!r.date).length}/${rows.length} datuma/približnih datuma. Neutvrđeni su na kraju.`);
  } catch (e) {
    status('Greška: ' + shortError(e));
  } finally {
    setWorking(false);
    // Return to the extension dashboard after navigating the other tabs.
    if (originalDashboardTab?.id) await chrome.tabs.update(originalDashboardTab.id, { active: true }).catch(() => {});
    render();
  }
}
function toCsv(detailed) {
  const q = v => `"${String(v ?? '').replace(/"/g, '""')}"`;
  const header = detailed ? ['Datum objave', 'Link', 'Platforma', 'Status', 'Izvor datuma', 'Napomena', 'Broj mogucih datuma'] : ['Datum objave', 'Link'];
  const data = sorted().map(r => detailed ?
    [fmt(r.date), r.target, r.platform, r.date?.confidence || 'nije utvrđeno', r.date?.source||'', displayNote(r), (r.options||[]).length] :
    [fmt(r.date), r.target]);
  // Keep the date field as a plain 19-character value without quotes or text.
  // Quote only the non-date fields to protect URLs, notes and delimiters.
  return [header, ...data].map(row => [String(row[0] ?? ''), ...row.slice(1).map(q)].join(';')).join('\r\n');
}
function download(detailed) {
  const file = new Blob(['\uFEFF' + toCsv(detailed)], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(file), a = document.createElement('a');
  a.href = url;
  a.download = detailed ? 'datumi_objava_detaljno.csv' : 'datumi_objava_2_kolone.csv';
  document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 6000);
}
async function copy() {
  const content = [['Datum objave', 'Link'], ...sorted().map(r => [fmt(r.date), r.target])]
    .map(values => values.join('\t')).join('\n');
  try { await navigator.clipboard.writeText(content); status('Kopirano – spremno za Excel / Google Sheets.'); }
  catch (e) { status('Kopiranje nije dostupno; preuzmi CSV.'); }
}
function simplify() {
  // Replace dense v5 interface through DOM, so only this JS file needs replacing.
  const style = elt('style');
  style.textContent = '.notice,.help,.settings,#restore-tabs,#hover-scan,#filter{display:none!important;} .inline-edit,.alt{display:none!important;} .toolbar{padding-block:12px;} .statusbox{margin-block:12px;}';
  document.head.append(style);
  const scan = $('scan');
  scan.textContent = 'Analiziraj sve objave redom';
  $('stop').textContent = 'Zaustavi';
  $('restore-tabs').remove();
  $('hover-scan').remove();
  // Remove filter label entirely; keep sorting and export available.
  $('filter').closest('label')?.remove();
  const action = $('stop').parentElement;
  const label = elt('label', null, 'check');
  const checkbox = document.createElement('input');
  checkbox.type = 'checkbox'; checkbox.id = 'auto-hover'; checkbox.checked = true;
  const text = elt('span', ' Pokušaj i puni Facebook datum prelaskom mišem (zahtijeva dozvolu)');
  label.append(checkbox, text); action.append(label);
  document.querySelector('.subtitle').textContent = 'Automatski, jedan po jedan tab · vrijeme Europe/Sarajevo';
  document.querySelector('.version').textContent = 'SEKVENCIJALNO 5.2 – CSV';
  const header = document.querySelector('.data table thead tr');
  if (header) {
    header.replaceChildren(...['Datum i vrijeme', 'Link', 'Platforma', 'Napomena'].map(h => elt('th', h)));
  }
  document.querySelector('.footer-info').textContent = 'CSV: YYYY-MM-DD HH:mm:ss u svakoj nepraznoj ćeliji, bez teksta ili navodnika. Ako sat nije poznat, 00:00:00 služi samo za sortiranje; detaljni CSV to bilježi. Kod uvoza u Excel datumsku kolonu možeš odabrati kao Tekst radi pouzdanog A–Z/Z–A sortiranja.';
  document.querySelector('.statusbox #status').textContent = 'Otvori objave u jednom prozoru i klikni „Analiziraj sve objave redom“. Za prvu provjeru dovoljno je 3–5 Facebook tabova.';
}
simplify();
$('scan').onclick = run;
$('stop').onclick = () => { stopped = true; status('Zaustavljam nakon trenutne objave…'); };
$('sort').onchange = render;
$('csv2').onclick = () => download(false);
$('csvfull').onclick = () => download(true);
$('copy').onclick = copy;
render();
