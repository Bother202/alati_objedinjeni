'use strict';
// Collect passively when the site loads or updates. Do not scrape via network.
if (!globalThis.__datumCollectorV5) {
  globalThis.__datumCollectorV5 = true;
  let last='', scheduled=false, observations=0;
  function collect(){
    scheduled=false;
    try {
      const result=DateProbe.inspect(document,location.href);
      const fingerprint=JSON.stringify({href:location.href,best:result?.best,alternatives:result?.alternatives,diagnostics:result?.diagnostics});
      if(fingerprint===last)return;
      last=fingerprint;
      chrome.runtime.sendMessage({kind:'DATUMI_COLLECTED',result}).catch(()=>{});
    } catch(e){}
  }
  function schedule(){if(scheduled)return;scheduled=true;setTimeout(collect,200);}
  chrome.runtime.onMessage.addListener((request,sender,respond)=>{
    try {
      if(request?.kind==='DATUMI_PING'){respond({ok:true,href:location.href});return false;}
      if(request?.kind==='DATUMI_READ'){const result=DateProbe.inspect(document,location.href);respond({ok:true,href:location.href,result});schedule();return false;}
      if(request?.kind==='DATUMI_SCROLL_HEADER'){respond({ok:true,scrolled:DateProbe.scrollHeader(document,location.href)});return false;}
      if(request?.kind==='DATUMI_HOVER_POINTS'){respond({ok:true,points:DateProbe.hoverPoints(document,location.href)});return false;}
      if(request?.kind==='DATUMI_TOOLTIP'){respond({ok:true,result:DateProbe.tooltipDate(document,request.x,request.y)});schedule();return false;}
    }catch(e){respond({ok:false,error:String(e?.message||e)});}
    return false;
  });
  collect();
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)schedule();});
  // Content can be hydrated late: a bounded observer, no heavy polling.
  const obs=new MutationObserver(()=>{if(++observations%15===0)schedule();});
  obs.observe(document.documentElement||document,{subtree:true,childList:true});
  setTimeout(schedule,900);
  setTimeout(schedule,2400);
  setTimeout(()=>obs.disconnect(),8500);
}
