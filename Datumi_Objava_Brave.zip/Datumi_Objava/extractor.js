/* Datumi objava 4.0: targeted timestamps, not arbitrary site-wide dates.
   Runs entirely on a local content script. No fetch, no cookies, no login data. */
(function (root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (root) root.DateProbe = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const MONTHS={
    januar:1,januara:1,january:1,jan:1,
    februar:2,februara:2,february:2,feb:2,veljaca:2,veljace:2,
    mart:3,marta:3,march:3,mar:3,ozujak:3,ozujka:3,
    april:4,aprila:4,apr:4,travanj:4,travnja:4,
    maj:5,maja:5,may:5,svibanj:5,svibnja:5,
    juni:6,juna:6,june:6,jun:6,lipanj:6,lipnja:6,
    juli:7,jula:7,july:7,jul:7,srpanj:7,srpnja:7,
    august:8,augusta:8,aug:8,kolovoz:8,kolovoza:8,
    septembar:9,septembra:9,september:9,sep:9,rujan:9,rujna:9,
    oktobar:10,oktobra:10,october:10,oct:10,listopad:10,listopada:10,
    novembar:11,novembra:11,november:11,nov:11,studeni:11,studenoga:11,
    decembar:12,decembra:12,december:12,dec:12,prosinac:12,prosinca:12
  };
  const platform=(url)=>{try{const h=new URL(url).hostname.toLowerCase();
    if(h==='facebook.com'||h.endsWith('.facebook.com'))return 'Facebook';
    if(h==='instagram.com'||h.endsWith('.instagram.com'))return 'Instagram';
    if(h==='tiktok.com'||h.endsWith('.tiktok.com'))return 'TikTok';
    if(h==='youtube.com'||h.endsWith('.youtube.com')||h==='youtu.be')return 'YouTube';
    if(h==='x.com'||h.endsWith('.x.com')||h==='twitter.com'||h.endsWith('.twitter.com'))return 'X';
  }catch(e){}return null;};
  const valid=(ms)=>Number.isFinite(ms)&&ms>=Date.UTC(2010,0,1)&&ms<=Date.now()+86400000;
  const timestampMs=(s)=>{if(typeof s!=='string')s=String(s);if(/^\d{10}$/.test(s))return +s*1000;if(/^\d{13}$/.test(s))return +s;return NaN;};
  const stripAcc=(s)=>s.toLocaleLowerCase('bs').normalize('NFD').replace(/[\u0300-\u036f]/g,'');
  function parseDate(input){
    if(input==null)return null;
    let s=String(input).replace(/\u00a0/g,' ').replace(/[\u200b-\u200d\ufeff]/g,'').trim();
    if(!s||s.length>150)return null;
    const tm=timestampMs(s);
    if(valid(tm))return {ms:tm,precision:'second',zoneKnown:true};
    if(/^20\d{2}-\d\d-\d\d$/.test(s)){
      const ms=sarajevoMillis(+s.slice(0,4),+s.slice(5,7),+s.slice(8,10),12,0,0);return valid(ms)?{ms,precision:'date',zoneKnown:false}:null;
    }
    if(/^20\d{2}-\d\d-\d\d[T ]\d\d:\d\d/.test(s)){
      const zone=/Z$|[+-]\d\d:?\d\d$/.test(s);
      const ms=Date.parse(s.replace(' ','T'));
      return valid(ms)?{ms,precision:'minute',zoneKnown:zone}:null;
    }
    // ISO dates on og tags may contain a timezone and fractional seconds.
    let clean=stripAcc(s.replace(/^(?:monday|tuesday|wednesday|thursday|friday|saturday|sunday|ponedjeljak|utorak|srijeda|cetvrtak|petak|subota|nedjelja|ponedeljak)\s*,?\s*/i,''));
    clean=clean.replace(/\s+/g,' ').replace(/\s+(?:at|u|um|en|a las)\s+/g,' ').trim();
    // Localized dates: 18.11.2026. 14:34 or 18/11/2026 14:34.
    let m=clean.match(/^(\d{1,2})[.\/-](\d{1,2})[.\/-](20\d\d)\.?\s*(\d{1,2}:\d\d(?::\d\d)?(?:\s*[ap]m)?)?/i);
    if(m)return calendarDate(+m[3],+m[2],+m[1],m[4],false);
    // Localized: 18. novembra 2026. 7:20 PM; November 18, 2026 at 7:20 PM
    clean=clean.replace(/[,]/g,' ').replace(/\s+/g,' ');
    m=clean.match(/^(\d{1,2})\.?\s+([a-zčćžđš]+)\s*(20\d\d)?\.?\s*(\d{1,2}:\d\d(?::\d\d)?(?:\s*[ap]m)?)?/u);
    if(m&&MONTHS[m[2]])return calendarDate(m[3]?+m[3]:null,MONTHS[m[2]],+m[1],m[4],!m[3]);
    m=clean.match(/^([a-zčćžđš]+)\s+(\d{1,2})\.?\s*(20\d\d)?\.?\s*(\d{1,2}:\d\d(?::\d\d)?(?:\s*[ap]m)?)?/u);
    if(m&&MONTHS[m[1]])return calendarDate(m[3]?+m[3]:null,MONTHS[m[1]],+m[2],m[4],!m[3]);
    return null;
  }
  // Facebook local wall-clock dates are in the user's social-media timezone.
  // Use the requested Europe/Sarajevo report timezone rather than assuming the
  // operating system/browser is configured to the same zone.
  const offsetFormatter=new Intl.DateTimeFormat('en-US',{timeZone:'Europe/Sarajevo',timeZoneName:'shortOffset'});
  function sarajevoMillis(y,mo,d,hh,mi,sec){
    const wall=Date.UTC(y,mo-1,d,hh,mi,sec);let guess=wall;
    for(let i=0;i<3;i++){
      const p=offsetFormatter.formatToParts(new Date(guess)).find(x=>x.type==='timeZoneName')?.value||'GMT+0';
      const m=p.match(/GMT([+-])(\d{1,2})(?::(\d{2}))?/);
      const off=m?(m[1]==='-'?-1:1)*(+m[2]*60+ +(m[3]||0)):0;
      const next=wall-off*60000;if(next===guess)break;guess=next;
    }
    return guess;
  }
  function calendarDate(year,month,day,hourText,yearInferred){
    if(!(month>=1&&month<=12&&day>=1&&day<=31))return null;
    const yearNow=new Date().getFullYear();let y=year??yearNow,hh=12,mi=0,sec=0;
    if(hourText){const m=String(hourText).match(/^(\d{1,2}):(\d\d)(?::(\d\d))?\s*(am|pm)?/i);if(!m)return null;
      hh=+m[1];mi=+m[2];sec=+(m[3]||0);const mer=(m[4]||'').toLowerCase();
      if(mer&&!(hh>=1&&hh<=12))return null;
      if(mer==='pm'&&hh<12)hh+=12;if(mer==='am'&&hh===12)hh=0;
    }
    if(hh>23||mi>59||sec>59)return null;
    let ms=sarajevoMillis(y,month,day,hh,mi,sec);
    if(yearInferred&&ms>Date.now()+86400000){y-=1;ms=sarajevoMillis(y,month,day,hh,mi,sec);}
    const local=new Intl.DateTimeFormat('en-CA',{timeZone:'Europe/Sarajevo',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date(ms));
    const check=Object.fromEntries(local.filter(p=>p.type!=='literal').map(p=>[p.type,+p.value]));
    if(!valid(ms)||check.year!==y||check.month!==month||check.day!==day)return null;
    return {ms,precision:hourText?'minute':'date',zoneKnown:false,yearInferred:!!yearInferred};
  }
  function candidate(raw,source,confidence,evidence){
    const parsed=parseDate(raw);if(!parsed)return null;
    const conf=parsed.yearInferred&&confidence==='direct'?'probable':confidence;
    return {...parsed,iso:new Date(parsed.ms).toISOString(),source,confidence:conf,evidence:String(evidence??raw).slice(0,130)};
  }
  function postKey(url){
    try{const u=new URL(url);if(platform(url)!=='Facebook')return null;
      const p=u.pathname.match(/\/(?:posts|reel|videos|video|photos)\/(pfbid[A-Za-z0-9]+|\d+)/);
      if(p)return p[1];const p2=u.pathname.match(/\/(\d{11,})\/videos/);if(p2)return p2[1];
      return u.searchParams.get('story_fbid')||u.searchParams.get('fbid')||u.searchParams.get('v')||null;
    }catch(e){return null;}
  }
  function values(el){
    if(!el)return [];
    const raw=[el.getAttribute?.('datetime'),el.getAttribute?.('data-utime'),el.getAttribute?.('title'),el.getAttribute?.('aria-label'),el.getAttribute?.('data-tooltip-content')];
    const t=(el.textContent||'').trim();if(t&&t.length<120)raw.push(t);
    return [...new Set(raw.filter(x=>x&&String(x).trim().length<150))];
  }
  function insert(found,raw,source,confidence,el){
    const c=candidate(raw,source,confidence,raw);
    if(c)found.push(c);
  }
  function pageScoped(doc,plat,found,url){
    let metaUrl='';
    const og=doc.querySelector('meta[property="og:url"]');if(og)metaUrl=og.content||'';
    const metaSelectors=['article:published_time','og:published_time','datePublished','uploadDate','publishDate','datecreated','pubdate'];
    for(const el of [...doc.querySelectorAll('meta[content]')].slice(0,100)){
      const k=(el.getAttribute('property')||el.getAttribute('itemprop')||el.getAttribute('name')||'');
      if(metaSelectors.some(x=>x.toLowerCase()===k.toLowerCase())){
        // Facebook OG may describe the page/reshare rather than the requested post.
        const key=plat==='Facebook'?postKey(url):null;
        if(plat==='Facebook'&&(!key||!metaUrl.includes(key)))continue;
        insert(found,el.content,`Meta ${k}`,plat==='Facebook'?'probable':'direct',el);
      }
    }
    const timeSelector=plat==='Instagram'?'main article time[datetime], article time[datetime], main time[datetime]':
      plat==='X'?'main article time[datetime], article time[datetime]':
      plat==='Facebook'?'[role="main"] [role="article"] time[datetime], main time[datetime]':
      'main time[datetime],time[datetime]';
    const elements=[...doc.querySelectorAll(timeSelector)].slice(0,10);
    for(const [i,el] of elements.entries()){
      if(el.closest('[role="dialog"], [role="menu"], footer, nav'))continue;
      for(const v of values(el))insert(found,v,`HTML time[datetime] ${i+1}`,i===0?'direct':'probable');
    }
    for(const scr of [...doc.querySelectorAll('script[type="application/ld+json"]')].slice(0,8)){
      if(scr.textContent.length>120000)continue;
      try{const o=JSON.parse(scr.textContent);const arr=Array.isArray(o)?o:o['@graph']||[o];
        for(const item of arr.slice(0,12)){if(!item||typeof item!=='object')continue;
          for(const key of ['datePublished','uploadDate','dateCreated'])if(item[key])insert(found,item[key],`JSON-LD ${key}`,plat==='Facebook'?'probable':'direct');
        }
      }catch(e){}
    }
    if(plat==='TikTok'){
      const el=doc.querySelector('script#__UNIVERSAL_DATA_FOR_REHYDRATION__,script#SIGI_STATE,script#__NEXT_DATA__');
      if(el&&el.textContent.length<2000000){try{const o=JSON.parse(el.textContent), id=(location.pathname.match(/\/video\/(\d+)/)||[])[1];
        const item=o?.__DEFAULT_SCOPE__?.['webapp.video-detail']?.itemInfo?.itemStruct||(id&&o?.ItemModule?.[id]);
        if(item?.createTime&&(!item.id||String(item.id)===id))insert(found,String(item.createTime),'TikTok createTime','direct');
      }catch(e){}}
    }
    if(plat==='YouTube'){
      const scripts=[...doc.querySelectorAll('script')].filter(s=>!s.src).slice(0,40);
      for(const s of scripts){const t=s.textContent;if(t.length>1000000||!t.includes('ytInitialPlayerResponse'))continue;
        for(const key of ['publishDate','uploadDate']){const m=t.match(new RegExp('"'+key+'"\\s*:\\s*"([^"\\\\]{10,30})"'));
          if(m)insert(found,m[1],`YouTube ${key}`,'direct');}
        break;
      }
    }
    return metaUrl;
  }
  function facebookDirect(doc,url,found,diagnostics){
    const key=postKey(url);
    if(!key){diagnostics.push('Facebook URL nema jednoznačan ID objave.');return {key,matched:0};}
    const anchors=[...doc.querySelectorAll('a[href]')].slice(0,1200);
    let matches=[];
    for(const a of anchors){let href=a.getAttribute('href')||'';
      if(href.includes(key))matches.push(a);
    }
    // These are the links to the exact post, not random comments/recommendations.
    for(const [i,a] of matches.slice(0,6).entries()){
      const before=found.length;
      const els=[a,...a.querySelectorAll('time,abbr,[datetime],[data-utime],[aria-label],[title]')].slice(0,24);
      const descr=a.getAttribute('aria-describedby');
      if(descr){for(const id of descr.split(/\s+/)){const described=doc.getElementById(id);if(described)els.push(described);}}
      for(const el of els)for(const v of values(el))insert(found,v,'Facebook: veza s tačnom objavom','direct');
      // A timestamp may be attached to an immediate wrapper rather than the link.
      if(found.length===before){let p=a.parentElement;
        for(let k=0;k<2&&p;k++,p=p.parentElement){
          const children=[...p.querySelectorAll('time,abbr,[data-utime]')].slice(0,6);
          for(const child of children){if(child.closest('[role="comment"]'))continue;
            for(const v of values(child))insert(found,v,'Facebook: oznaka uz tačnu objavu','probable');}
        }
      }
    }
    // When no permalink anchor is hydrated, inspect only the early header of the first main article.
    if(!matches.length){
      const main=doc.querySelector('[role="main"],main');
      const article=main?.querySelector('[role="article"],article');
      if(article){
        const candidates=[...article.querySelectorAll('abbr, time, a[title],a[aria-label],span[title]')].slice(0,20);
        for(const el of candidates.slice(0,8)){
          if(el.closest('[role="comment"]'))continue;
          for(const v of values(el))insert(found,v,'Facebook: prva objava, zaglavlje','probable');
        }
      }
    }
    return {key,matched:matches.length};
  }
  // Facebook can embed many timestamps: the post, shared posts, comments,
  // recommendations and unrelated objects. Rank evidence, never imply that
  // a timestamp found anywhere on the page is confirmed publication time.
  function fbScriptCandidates(doc,key,diagnostics){
    const observations=new Map();let examined=0;
    const scripts=[...doc.querySelectorAll('script')];
    for(const sc of scripts){
      const s=sc.textContent||'';
      if(!s||s.length>2200000)continue;
      examined+=s.length;if(examined>2500000)break;
      const timeRE=/(?:\\?"(?:creation_time|publish_time|created_time|story_creation_time)\\?"|\b(?:creation_time|publish_time|created_time)\b)\s*:\s*\\?"?(1[4-9]\d{8})/g;
      let m,steps=0;
      while((m=timeRE.exec(s))&&++steps<70){
        const ms=Number(m[1])*1000;if(!valid(ms))continue;
        const nearBack=key?s.lastIndexOf(key,m.index):-1;
        const nearForward=key?s.indexOf(key,m.index):-1;
        const distance=Math.min(nearBack<0?Infinity:m.index-nearBack,nearForward<0?Infinity:nearForward-m.index);
        const linked=distance<=3300;
        const field=m[0].match(/(?:creation_time|publish_time|created_time|story_creation_time)/)?.[0]||'time';
        const nearby=s.slice(Math.max(0,m.index-180),Math.min(s.length,m.index+180));
        const commentContext=/comment_id|comment_count|comment_time|reply_comment|feedback_reaction/i.test(nearby);
        // Distance from exact Facebook post ID is stronger evidence than mere
        // occurrence of the field. Field type and repeated occurrences help.
        let score=linked?(distance<200?94:distance<650?85:distance<1600?72:60):11;
        if(field==='publish_time'||field==='story_creation_time')score+=7;
        if(commentContext)score-=24;
        const old=observations.get(ms);
        if(!old)observations.set(ms,{ms,score,linked,count:1,distance,field});
        else {old.count+=1;if(score>old.score){old.score=score;old.distance=distance;old.field=field;}
          old.linked ||= linked;}
      }
    }
    const items=[...observations.values()];
    if(!items.length)return [];
    const linked=items.filter(x=>x.linked);
    if(linked.length>1)diagnostics.push(`${linked.length} moguća datuma povezana s ID-om objave`);
    if(!linked.length)diagnostics.push(`${items.length} datuma u kodu, ali nijedan neposredno povezan s ID-om objave`);
    const chosen=linked.length?linked:items;
    chosen.sort((a,b)=>(b.score+Math.min(b.count,3)*2)-(a.score+Math.min(a.count,3)*2)||a.ms-b.ms);
    return chosen.slice(0,12).map(o=>{
      const source=o.linked?`Facebook: ${o.field} blizu ID-a objave`:`Facebook: ${o.field} iz koda (ID nije povezan)`;
      const c=candidate(String(Math.round(o.ms/1000)),source,o.linked?'probable':'ambiguous');
      if(c){c.score=o.score+Math.min(o.count,3)*2;c.linkedToPost=o.linked;c.hits=o.count;c.distance=o.linked?o.distance:null;}
      return c;
    }).filter(Boolean);
  }
  function evidenceScore(c){
    let s=({direct:110,manual:140,id:105,probable:69,ambiguous:13,estimate:15}[c.confidence]||0);
    const name=c.source||'';
    if(/Facebook: veza s tačnom objavom/i.test(name))s+=72;
    else if(/Facebook: oznaka uz tačnu objavu/i.test(name))s+=57;
    else if(/Facebook: prva objava, zaglavlje/i.test(name))s+=37;
    else if(/Facebook: (?:creation_time|publish_time|created_time|story_creation_time) blizu ID/i.test(name))s+=18;
    else if(/Meta /i.test(name))s+=19;
    else if(/HTML time\[datetime\] 1/i.test(name))s+=17;
    if(Number.isFinite(c.score))s+=c.score;
    if(c.precision==='date')s-=3;
    return s;
  }
  function inspect(doc,url){
    const plat=platform(url),found=[],diagnostics=[];
    if(!plat||!doc)return {best:null,found:[],alternatives:[],diagnostics:['Nepodržana stranica']};
    const fb=plat==='Facebook'?facebookDirect(doc,url,found,diagnostics):null;
    pageScoped(doc,plat,found,url);
    // The script fallback is only required when we have no direct post permalink
    // evidence; never use it to displace a precise date on the visible post.
    if(plat==='Facebook'&&!found.some(c=>c.source?.includes('tačnom objavom'))){
      found.push(...fbScriptCandidates(doc,fb?.key,diagnostics));
    }
    const byMs=new Map();
    for(const item of found){
      if(!Number.isFinite(item?.ms))continue;
      const score=evidenceScore(item);
      const prev=byMs.get(item.ms);
      if(!prev)byMs.set(item.ms,{...item,rank:score,support:1});
      else {prev.support+=1;if(score>prev.rank){byMs.set(item.ms,{...item,rank:score,support:prev.support});}}
    }
    const candidates=[...byMs.values()];
    candidates.sort((a,b)=>(b.rank+Math.min(b.support,3)*4)-(a.rank+Math.min(a.support,3)*4)||a.ms-b.ms);
    let best=candidates[0]||null;
    const multiple=candidates.length>1;
    if(best){
      best={...best};
      if(best.confidence==='ambiguous')best.confidence='estimate';
      // If only generic script dates exist, earliest among equally ranked
      // candidates is a weak heuristic, NOT verified post publication.
      if(multiple){
        const diff=(candidates[0].rank+Math.min(candidates[0].support,3)*4)-
          (candidates[1].rank+Math.min(candidates[1].support,3)*4);
        best.autoSelected=true;
        best.selectionGap=diff;
        best.lowConfidence=best.confidence==='estimate'||diff<10;
        diagnostics.push(best.lowConfidence
          ?`Automatski izabran kandidat između ${candidates.length} datuma; niska pouzdanost — provjeri po potrebi`
          :`Automatski izabran najjače povezan datum između ${candidates.length} kandidata`);
      }
    }
    return {
      best,
      alternatives:candidates.slice(0,15),
      found:candidates.filter(c=>c.confidence!=='ambiguous').slice(0,16),
      diagnostics,
      matchedPostLinks:fb?.matched??null,
      selection:{multiple,count:candidates.length,method:multiple?(best?.lowConfidence?'slaba procjena':'rangiranje prema povezanosti s objavom'):'jedan kandidat'}
    };
  }
  function scrollHeader(doc,url){
    if(platform(url)!=='Facebook')return false;
    const key=postKey(url);
    let target=key?[...doc.querySelectorAll('a[href]')].slice(0,1000).find(a=>(a.getAttribute('href')||'').includes(key)):null;
    if(!target){const first=doc.querySelector('[role="main"] [role="article"],main article');
      target=[...first?.querySelectorAll('a')||[]].find(a=>/\d/.test((a.textContent||'').trim())&&(a.textContent||'').length<40)||first;
    }
    if(target){target.scrollIntoView({block:'center',behavior:'instant'});return true;}
    return false;
  }
  function hoverPoints(doc,url){
    if(platform(url)!=='Facebook')return [];
    const key=postKey(url),points=[],seen=new Set();
    const anchors=[...doc.querySelectorAll('a[href]')].slice(0,900);
    const matches=key?anchors.filter(a=>(a.getAttribute('href')||'').includes(key)).sort((a,b)=>{
      const score=el=>{const t=((el.textContent||'')+' '+(el.getAttribute('aria-label')||'')).trim();
        return (/\d/.test(t)?3:0)+(t.length<70?2:0)+(/\d{1,2}:\d{2}|\b(?:at|nov|oct|sep|h|d|m|sati|prije)\b/i.test(t)?6:0);
      };return score(b)-score(a);
    }).slice(0,5):[];
    const roots=matches.length?matches:[...doc.querySelectorAll('[role="main"] [role="article"] a,main article a')].slice(0,16);
    const candidates=matches.length?roots:roots.filter(a=>{const t=(a.textContent||'').trim();return t.length<45&&/\d/.test(t);});
    for(const el of candidates){const r=el.getBoundingClientRect();if(r.width<2||r.height<2||r.top<0||r.top>=innerHeight||r.left<0||r.left>=innerWidth)continue;
      const x=Math.round(r.left+Math.min(r.width-1,Math.max(2,r.width/2))),y=Math.round(r.top+r.height/2);
      const k=x+','+y;if(seen.has(k))continue;seen.add(k);
      points.push({x,y,source:matches.length?'tačan link':'prva objava'});if(points.length>=2)break;
    }
    return points;
  }
  function tooltipDate(doc,x,y){
    const els=[...doc.querySelectorAll('[role="tooltip"],[data-testid*="tooltip"],[id*="tooltip"],abbr[title]')].slice(-80);
    const list=[];
    for(const el of els){const rect=el.getBoundingClientRect();if(!rect.width||!rect.height)continue;
      if(x!=null&&y!=null&&Math.abs((rect.left+rect.right)/2-x)>450&&Math.abs((rect.top+rect.bottom)/2-y)>300)continue;
      for(const v of values(el)){const c=candidate(v,'Facebook: puni datum nakon hovera','direct');if(c)list.push(c);}
    }
    const unique=[...new Map(list.map(c=>[c.ms,c])).values()];
    return unique.length===1?{best:unique[0],count:1}:{best:null,count:unique.length};
  }
  function decodedId(url){
    try{const u=new URL(url),p=platform(url);
      if(p==='X'){const m=u.pathname.match(/\/status\/(\d{15,21})/);if(m){const ms=Number((BigInt(m[1])>>22n)+1288834974657n);if(valid(ms))return candidate(ms,'X ID objave','id');}}
      if(p==='TikTok'){const m=u.pathname.match(/\/video\/(\d{17,21})/);if(m){const ms=Number(BigInt(m[1])>>32n)*1000;if(valid(ms))return candidate(ms,'TikTok ID — procjena','estimate');}}
      if(p==='Instagram'){const m=u.pathname.match(/\/(?:p|reel|reels|tv)\/([\w-]{8,15})/);if(m){
        const alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';let id=0n;
        for(const ch of m[1]){let v=alphabet.indexOf(ch);if(v<0)return null;id=id*64n+BigInt(v);}
        const ms=Number((id>>23n)+1314220021721n);if(valid(ms))return candidate(ms,'Instagram ID — procjena nastanka','estimate');
      }}
    }catch(e){}return null;
  }
  return {platform,parseDate,postKey,inspect,scrollHeader,hoverPoints,tooltipDate,decodedId};
});
