// Otvori bočni panel nakon klika na ikonu. Nema pristupa sadržaju tabova.
chrome.action.onClicked.addListener(async (tab) => {
  try {
    if (!chrome.sidePanel?.open) throw new Error('Nepodržan bočni panel');
    await chrome.sidePanel.open({ windowId: tab.windowId });
  } catch {
    await chrome.tabs.create({ url: chrome.runtime.getURL('panel.html') });
  }
});
