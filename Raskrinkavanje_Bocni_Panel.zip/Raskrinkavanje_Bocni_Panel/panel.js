const input = document.getElementById('siteUrl');
const frame = document.getElementById('frame');
const settings = document.getElementById('settings');
const msg = document.getElementById('msg');
let currentUrl = '';
function validate(raw) {
  try { const url = new URL(raw.trim()); return url.protocol === 'https:' && url.hostname.includes('.') ? url.href : ''; }
  catch { return ''; }
}
function showSite(url) {
  currentUrl = url;
  frame.hidden = !url;
  document.getElementById('empty').hidden = Boolean(url);
  if (url) frame.src = url;
  else frame.removeAttribute('src');
}
async function save() {
  const url = validate(input.value);
  if (!url) { msg.textContent = 'Unesi punu HTTPS adresu (https://...).'; return; }
  await chrome.storage.local.set({alatnica_url:url});
  msg.textContent = 'Adresa je sačuvana.';
  showSite(url);settings.hidden = true;
}
document.getElementById('saveUrl').addEventListener('click',save);
input.addEventListener('keydown',(event)=>{if(event.key==='Enter')save();});
document.getElementById('toggleSettings').addEventListener('click',()=>{settings.hidden=!settings.hidden;});
document.getElementById('startSettings').addEventListener('click',()=>{settings.hidden=false;input.focus();});
document.getElementById('reload').addEventListener('click',()=>{if(currentUrl) frame.src=currentUrl;});
document.getElementById('openTab').addEventListener('click',()=>{if(currentUrl)chrome.tabs.create({url:currentUrl}); else settings.hidden=false;});
chrome.storage.local.get('alatnica_url').then((data)=>{const url=validate(data.alatnica_url||'https://bother202.github.io/alati_objedinjeni/');input.value=url;showSite(url);settings.hidden=Boolean(url);});

const logo = new Image(); logo.addEventListener('load',()=>document.querySelectorAll('.clown-logo').forEach(e=>e.classList.add('has-official-logo')));logo.src='https://raskrinkavanje.ba/images/og.png';
