FB SCREENSHOT FORMATS v6.1 (1.4.1) — CHROME / EDGE
================================================

NAMJENA
Ekstenzija otvara postojeću Facebook stranicu/objavu u odabranom prozoru i pravi fotografije
stvarno prikazanog sadržaja. Ne rekonstruiše objave, ne mijenja njihov tekst i ne traži lozinku.

FORMATI PRIKAZA
- Mobilni: 430 × 920
- Tablet: 768 × 1024
- Desktop: 1200 × 900
- Prilagođeno: vlastita širina i visina

Dimenzije se odnose na veličinu prozora koji Chrome/Edge otvara. Dio prostora može zauzimati
sam okvir preglednika. Sve metode snimanja dostupne su u svakom od četiri formata prikaza.

NAČINI SNIMANJA

1) „📷 Vidljivi prozor“ — jednim klikom snima sve što je TRENUTNO VIDLJIVO u sadržaju
   preglednika, uključujući Facebook objavu i eventualne dijelove stranice oko nje.
   Alatna traka ekstenzije se automatski sakrije sa snimka. Ne snima adresnu traku
   niti okvir Chromea/Edgea. Ne skrola automatski.

2) „▤ Cijela objava“ — klikni dugme, a zatim klikni unutar Facebook objave kada se
   pojavi plavi okvir. Ekstenzija pokušava prepoznati cijeli članak/objavu, automatski
   proskrolati kroz nju i spojiti vidljive dijelove u JEDNU VERTIKALNU FOTOGRAFIJU.
   Sprema samo okvir odabrane objave, bez ostatka feeda, kada Facebook označi taj okvir.
   Po završetku vraća prethodnu poziciju skrolanja.

   VAŽNO: Na Facebooku najprije klikni „Prikaži više“ ako želiš i skriveni dio teksta.
   Zavisno od Facebookovog izgleda stranice, posebno u foto/video modalima i kod dinamičkih
   objava, prepoznavanje ili automatsko spajanje može biti onemogućeno. Tada upotrijebi
   „Vidljivi prozor“ ili postojeći „Gornji dio“ + „Donji dio“ + „Spoji“.
   Izuzetno velike objave imaju tehničko ograničenje veličine slike.

3) „✂ Jedan crop“ i „① Gornji dio / ② Donji dio / ③ Spoji“ — ostaju dostupni,
   uz dosadašnje podešavanje razmaka: 0 / 8 / 12 / 20 / 32 px.

PNG I JPG
U alatnoj traci izaberi „Slika: PNG“ ili „Slika: JPG“.
Izbor važi za sve načine snimanja, uključujući jedan crop i spojenu fotografiju.
PNG je početni format i čuva sliku bez gubitka kvaliteta; JPG pravi kompresovanu
fotografiju, uz kvalitet 94 %. Izbor se pamti za idući put.

OSTALE OPCIJE
- Zoom: − / + / 100 %.
- Reset: poništi prethodno sačuvane gornje i donje dijelove.
- Sakrij: sklanja alatnu traku; dugme FBMS vraća je na ekran.
- U popupu se automatski prepoznaje aktivni Facebook tab.
- Ostaje mogućnost ručnog lijepljenja Facebook URL-a.
- Odabrane dimenzije se pamte.

INSTALACIJA U CHROME
1. Raspakuj ZIP na stalnu lokaciju.
2. Otvori chrome://extensions .
3. Uključi „Developer mode“ (Način rada za razvojne programere).
4. Klikni „Load unpacked“ (Učitaj raspakovano).
5. Izaberi raspakovani folder „FB_Screenshot_Formats_FIXED“ (u kojem je manifest.json).
6. Otvori Facebook, klikni ikonu ekstenzije i izaberi format.

EDGE
Isti postupak na edge://extensions .

AKO IMAŠ STARIJU VERZIJU
Možeš zamijeniti datoteke u postojećem folderu (kad je ekstenzija učitana iz tog foldera),
zatim kliknuti „Reload“ na stranici s ekstenzijama i osvježiti otvorenu Facebook karticu.
Ako novu verziju učitavaš iz drugog foldera, možeš ukloniti staru da nema duplih ikona.

PRIVATNOST I NAPOMENE
Sadržaj za screenshot dolazi s tvoje prijavljene Facebook stranice i obrađuje se lokalno
u Chromeu/Edgeu. Ekstenzija ne šalje fotografije na vanjske servere.
Snimke se preuzimaju kroz Chrome/Edge dijalog za spremanje.
Facebook može mijenjati svoj HTML i ponašanje pri skrolanju; zbog toga ne može biti
zagarantovano automatsko prepoznavanje svake objave u svim njegovim prikazima.

TEHNIČKA PROVJERA
Kod je provjeren sintaktički, a snimanje cijelog prozora, PNG/JPG izvoz i spajanje dugačkih
objava testirani su u kontrolisanoj Chromium stranici, uključujući stranicu s unutrašnjim
scroll prozorom. Rad na prijavljenom Facebooku nije bilo moguće ovdje provjeriti.

ISPRAVKA v6.1 — PREPOZNAVANJE OBJAVA
Facebook na pojedinim stranicama objave (permalink, dijalozi, mobilni prikaz) ne koristi
HTML oznaku article niti role=article. Verzija v6.1 prepoznaje dodatne Facebookove
strukture i, ako oznake ne postoje, bira okvir objave na osnovu rasporeda stranice.

Dugme „Cijela objava“: pomjeri miš iznad objave i pogledaj PLAVI OKVIR prije klika.
Ako okvir nije odgovarajući, strelica ↑ bira veći, a ↓ manji ponuđeni okvir.
Pritisni Esc da odustaneš. Ako ni jedan okvir ne odgovara, koristi „Jedan crop“.
Za jako duge objave preporučuje se otvaranje objave klikom na datum/vrijeme objave.

Nakon zamjene fajlova otvori chrome://extensions ili edge://extensions, klikni Reload
i OBAVEZNO OSVJEŽI Facebook stranicu ili prozor objave (Ctrl+R).
