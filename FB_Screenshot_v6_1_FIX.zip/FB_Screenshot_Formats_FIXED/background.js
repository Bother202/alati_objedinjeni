
const mobileTabs = new Set();

// Chrome allows at most two captureVisibleTab calls per second. A queue also
// prevents parallel clicks from producing a screenshot of a different tab.
let captureQueue = Promise.resolve();
let previousCaptureAt = 0;
function queuedCapture(windowId, tabId) {
  const operation = captureQueue.catch(() => {}).then(async () => {
    const delay = Math.max(0, 620 - (Date.now() - previousCaptureAt));
    if (delay) await new Promise(resolve => setTimeout(resolve, delay));
    const [active] = await chrome.tabs.query({ active: true, windowId });
    if (!active || active.id !== tabId) {
      throw new Error("Za snimanje vrati fokus na Facebook prozor s objavom.");
    }
    previousCaptureAt = Date.now();
    return chrome.tabs.captureVisibleTab(windowId, { format: "png" });
  });
  captureQueue = operation.catch(() => {});
  return operation;
}

function normalizeWindowDimension(value, fallback, minimum) {
  const parsed = Number.parseInt(value, 10);
  return Number.isFinite(parsed) && parsed >= minimum ? parsed : fallback;
}

function waitForComplete(tabId, timeout = 25000) {
  return new Promise((resolve, reject) => {
    let finished = false;
    const timer = setTimeout(() => {
      if (!finished) {
        finished = true;
        chrome.tabs.onUpdated.removeListener(onUpdated);
        reject(new Error("Facebook stranica se nije učitala na vrijeme."));
      }
    }, timeout);

    function onUpdated(id, info, tab) {
      if (id === tabId && info.status === "complete" && !finished) {
        finished = true;
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(onUpdated);
        resolve(tab);
      }
    }
    chrome.tabs.onUpdated.addListener(onUpdated);

    chrome.tabs.get(tabId).then(tab => {
      if (tab.status === "complete" && !finished) {
        finished = true;
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(onUpdated);
        resolve(tab);
      }
    }).catch(() => {});
  });
}

async function activateToolbar(tabId) {
  try {
    await chrome.tabs.sendMessage(tabId, { type: "FBMS_ACTIVATE" });
  } catch {
    try {
      await chrome.scripting.executeScript({
        target: { tabId },
        files: ["content.js"]
      });
      await chrome.tabs.sendMessage(tabId, { type: "FBMS_ACTIVATE" });
    } catch (_) {}
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "OPEN_MOBILE") {
    (async () => {
      try {
        const requestedWidth = normalizeWindowDimension(msg.width, 430, 320);
        const requestedHeight = normalizeWindowDimension(msg.height, 920, 400);

        const win = await chrome.windows.create({
          url: msg.url,
          type: "popup",
          width: requestedWidth,
          height: requestedHeight,
          focused: true
        });
        const tab = win.tabs && win.tabs[0];
        if (!tab) throw new Error("Nije moguće otvoriti prozor.");
        mobileTabs.add(tab.id);
        try { await waitForComplete(tab.id); } catch (_) {}
        await new Promise(r => setTimeout(r, 900));
        await activateToolbar(tab.id);
        sendResponse({ ok: true });
      } catch (e) {
        sendResponse({ ok: false, error: e.message || String(e) });
      }
    })();
    return true;
  }

  if (msg.type === "CAPTURE_VISIBLE") {
    (async () => {
      try {
        const tab = sender.tab;
        if (!tab || tab.windowId == null) throw new Error("Nema aktivnog Facebook prozora.");
        const dataUrl = await queuedCapture(tab.windowId, tab.id);
        sendResponse({ ok: true, dataUrl });
      } catch (e) {
        sendResponse({ ok: false, error: e.message || String(e) });
      }
    })();
    return true;
  }

  if (msg.type === "DOWNLOAD_DATA_URL") {
    (async () => {
      try {
        const id = await chrome.downloads.download({
          url: msg.dataUrl,
          filename: msg.filename || `facebook-screenshot-${Date.now()}.png`,
          saveAs: true
        });
        sendResponse({ ok: true, downloadId: id });
      } catch (e) {
        sendResponse({ ok: false, error: e.message || String(e) });
      }
    })();
    return true;
  }

  if (msg.type === "SET_ZOOM") {
    (async () => {
      try {
        const tabId = sender.tab?.id;
        if (!tabId) throw new Error("Nema aktivnog taba.");
        const current = await chrome.tabs.getZoom(tabId);
        let next = current + Number(msg.delta || 0);
        next = Math.max(0.5, Math.min(1.5, next));
        await chrome.tabs.setZoom(tabId, next);
        sendResponse({ ok: true, zoom: next });
      } catch (e) {
        sendResponse({ ok: false, error: e.message || String(e) });
      }
    })();
    return true;
  }

  if (msg.type === "RESET_ZOOM") {
    (async () => {
      try {
        const tabId = sender.tab?.id;
        if (!tabId) throw new Error("Nema aktivnog taba.");
        await chrome.tabs.setZoom(tabId, 1);
        sendResponse({ ok: true, zoom: 1 });
      } catch (e) {
        sendResponse({ ok: false, error: e.message || String(e) });
      }
    })();
    return true;
  }
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (mobileTabs.has(tabId) && changeInfo.status === "complete") {
    setTimeout(() => activateToolbar(tabId), 800);
  }
});
chrome.tabs.onRemoved.addListener(tabId => mobileTabs.delete(tabId));
