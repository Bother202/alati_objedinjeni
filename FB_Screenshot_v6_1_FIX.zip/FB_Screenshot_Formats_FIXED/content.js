(() => {
  // One copy of the controls per Facebook tab.
  if (window.__FBMS_V61__) return;
  window.__FBMS_V61__ = true;

  let toolbar = null;
  let overlay = null;
  let box = null;
  let selecting = false;
  let pickingPost = false;
  let captureBusy = false;
  let gapPx = 12;
  const parts = { top: null, bottom: null };

  function send(message) {
    return new Promise(resolve => {
      try {
        chrome.runtime.sendMessage(message, response => {
          const error = chrome.runtime.lastError;
          resolve(error ? { ok: false, error: error.message } : (response || { ok: false, error: "Nema odgovora ekstenzije." }));
        });
      } catch (error) {
        resolve({ ok: false, error: error.message || String(error) });
      }
    });
  }

  function timestamp() {
    const d = new Date(), p = n => String(n).padStart(2, "0");
    return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}_${p(d.getHours())}-${p(d.getMinutes())}-${p(d.getSeconds())}`;
  }

  const pause = ms => new Promise(resolve => setTimeout(resolve, ms));

  function imageType() {
    return toolbar?.querySelector("#fbms-image-type")?.value === "jpeg" ? "jpeg" : "png";
  }

  function outputFormat() {
    return imageType() === "jpeg"
      ? { mime: "image/jpeg", extension: "jpg" }
      : { mime: "image/png", extension: "png" };
  }

  function canvasToImage(canvas) {
    const format = outputFormat();
    return canvas.toDataURL(format.mime, format.mime === "image/jpeg" ? 0.94 : undefined);
  }

  function showError(error) {
    const message = typeof error === "string" ? error : error?.message || "Nepoznata greška.";
    alert(message);
  }

  function setBusy(value) {
    captureBusy = value;
    toolbar?.querySelectorAll('button[data-act]').forEach(btn => { btn.disabled = value; });
    const status = toolbar?.querySelector("#fbms-status");
    if (value && status) status.textContent = "Snimanje u toku…";
    if (!value) updateStatus();
  }

  function makeToolbar() {
    if (toolbar) return;
    toolbar = document.createElement("div");
    toolbar.id = "fbms-toolbar";
    toolbar.innerHTML = `
      <div class="fbms-row">
        <button data-act="viewport" class="primary" title="Sačuvaj sve što je vidljivo u prozoru, bez trake ekstenzije">📷 Vidljivi prozor</button>
        <button data-act="fullpost" title="Klikni unutar objave; ekstenzija će je skrolati i spojiti u jednu fotografiju">▤ Cijela objava</button>
        <span class="sep"></span>
        <button data-act="single">✂ Jedan crop</button>
        <span class="sep"></span>
        <button data-act="top">① Gornji dio</button>
        <button data-act="bottom">② Donji dio</button>
        <button data-act="join">③ Spoji</button>
      </div>
      <div class="fbms-row">
        <span id="fbms-status">Gornji: — · Donji: —</span>
        <span class="sep"></span>
        <label>Slika
          <select id="fbms-image-type" aria-label="Format fotografije">
            <option value="png" selected>PNG</option>
            <option value="jpeg">JPG</option>
          </select>
        </label>
        <label>Razmak
          <select id="fbms-gap">
            <option value="0">0</option>
            <option value="8">8 px</option>
            <option value="12" selected>12 px</option>
            <option value="20">20 px</option>
            <option value="32">32 px</option>
          </select>
        </label>
        <span class="sep"></span>
        <button data-act="minus">−</button>
        <button data-act="reset">100%</button>
        <button data-act="plus">+</button>
        <button data-act="clear">Reset</button>
        <button data-act="hide">Sakrij</button>
      </div>
    `;
    document.documentElement.appendChild(toolbar);

    const style = document.createElement("style");
    style.id = "fbms-style";
    style.textContent = `
      #fbms-toolbar{
        position:fixed!important;left:8px!important;right:8px!important;bottom:8px!important;
        z-index:2147483647!important;background:rgba(18,22,26,.97)!important;color:white!important;
        padding:7px!important;border-radius:10px!important;display:flex!important;flex-direction:column!important;
        gap:5px!important;box-shadow:0 4px 18px rgba(0,0,0,.35)!important;
        font-family:Arial,Helvetica,sans-serif!important;font-size:11px!important;
      }
      #fbms-toolbar .fbms-row{display:flex!important;gap:5px!important;align-items:center!important;flex-wrap:wrap!important}
      #fbms-toolbar button{
        appearance:none!important;border:1px solid rgba(255,255,255,.22)!important;background:#30363d!important;
        color:white!important;border-radius:7px!important;padding:6px 7px!important;cursor:pointer!important;
        font:600 10px Arial,Helvetica,sans-serif!important;white-space:nowrap!important;
      }
      #fbms-toolbar button.primary{background:#1769aa!important}
      #fbms-toolbar button.saved{background:#18794e!important}
      #fbms-toolbar button:disabled{opacity:.55!important;cursor:wait!important}
      #fbms-toolbar .sep{width:1px!important;height:21px!important;background:rgba(255,255,255,.18)!important}
      #fbms-toolbar label{display:flex!important;align-items:center!important;gap:4px!important;color:#ddd!important;font:600 10px Arial!important}
      #fbms-toolbar select{background:#30363d!important;color:white!important;border:1px solid rgba(255,255,255,.2)!important;border-radius:5px!important;padding:3px!important}
      #fbms-status{color:#cbd5df!important;font:600 10px Arial!important}
      #fbms-select-overlay{position:fixed!important;inset:0!important;z-index:2147483645!important;cursor:crosshair!important;background:rgba(0,0,0,.06)!important}
      #fbms-select-box{position:fixed!important;z-index:2147483646!important;border:2px solid #28a7ff!important;background:rgba(40,167,255,.10)!important;pointer-events:none!important}
      #fbms-tip{position:fixed!important;top:10px!important;left:50%!important;transform:translateX(-50%)!important;z-index:2147483647!important;background:#111!important;color:white!important;border-radius:8px!important;padding:8px 11px!important;font:600 11px Arial!important;pointer-events:none!important}
      #fbms-post-highlight{position:fixed!important;z-index:2147483645!important;border:3px solid #28a7ff!important;border-radius:5px!important;background:rgba(40,167,255,.05)!important;pointer-events:none!important;box-sizing:border-box!important}
    `;
    document.documentElement.appendChild(style);

    toolbar.querySelector("#fbms-gap").addEventListener("change", e => { gapPx = Number(e.target.value); });
    chrome.storage.local.get(["fbms_image_type"], settings => {
      if (settings.fbms_image_type === "jpeg") toolbar.querySelector("#fbms-image-type").value = "jpeg";
    });
    toolbar.querySelector("#fbms-image-type").addEventListener("change", e => {
      chrome.storage.local.set({ fbms_image_type: e.target.value });
    });

    toolbar.addEventListener("click", e => {
      const action = e.target?.dataset?.act;
      if (!action || captureBusy || selecting || pickingPost) return;
      if (action === "viewport") captureViewport();
      if (action === "fullpost") choosePost();
      if (action === "single") selectRegion("single");
      if (action === "top") selectRegion("top");
      if (action === "bottom") selectRegion("bottom");
      if (action === "join") joinParts();
      if (action === "clear") clearParts();
      if (action === "minus") setZoom(-0.1);
      if (action === "plus") setZoom(0.1);
      if (action === "reset") resetZoom();
      if (action === "hide") hideToolbar();
    });
    updateStatus();
  }

  function hideToolbar() {
    toolbar.style.display = "none";
    document.getElementById("fbms-restore")?.remove();
    const btn = document.createElement("button");
    btn.id = "fbms-restore";
    btn.textContent = "FBMS";
    Object.assign(btn.style, {position:"fixed",right:"8px",bottom:"8px",zIndex:"2147483647",border:"0",borderRadius:"7px",padding:"7px 8px",background:"#20252a",color:"#fff",font:"700 10px Arial",cursor:"pointer",opacity:".75"});
    btn.onclick = () => { btn.remove(); toolbar.style.display = "flex"; };
    document.documentElement.appendChild(btn);
  }

  async function setZoom(delta) {
    const result = await send({ type: "SET_ZOOM", delta });
    if (result.ok) toolbar.querySelector('[data-act="reset"]').textContent = `${Math.round(result.zoom * 100)}%`;
    else showError(result.error);
  }

  async function resetZoom() {
    const result = await send({ type: "RESET_ZOOM" });
    if (result.ok) toolbar.querySelector('[data-act="reset"]').textContent = "100%";
    else showError(result.error);
  }

  function updateStatus() {
    const status = toolbar?.querySelector("#fbms-status");
    if (!status) return;
    status.textContent = `Gornji: ${parts.top ? parts.top.w + "×" + parts.top.h : "—"} · Donji: ${parts.bottom ? parts.bottom.w + "×" + parts.bottom.h : "—"}`;
    toolbar.querySelector('[data-act="top"]').classList.toggle("saved", !!parts.top);
    toolbar.querySelector('[data-act="bottom"]').classList.toggle("saved", !!parts.bottom);
  }

  function clearParts() {
    parts.top = null;
    parts.bottom = null;
    updateStatus();
  }

  // Hide only the extension's own controls. The Facebook post is not reconstructed
  // or rewritten; all images are captured from the actual rendered browser tab.
  async function whileControlsHidden(task) {
    const elements = [toolbar, document.getElementById("fbms-restore"), overlay, box, document.getElementById("fbms-tip"), document.getElementById("fbms-post-highlight")].filter(Boolean);
    const visibility = elements.map(el => el.style.visibility);
    elements.forEach(el => { el.style.visibility = "hidden"; });
    try {
      await pause(120);
      return await task();
    } finally {
      elements.forEach((el, index) => { if (el.isConnected) el.style.visibility = visibility[index]; });
    }
  }

  async function takeScreenshot() {
    const response = await send({ type: "CAPTURE_VISIBLE" });
    if (!response.ok || !response.dataUrl) throw new Error(response.error || "Screenshot nije uspio.");
    return response.dataUrl;
  }

  async function loadImage(src) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = () => reject(new Error("Nije moguće učitati fotografiju."));
      img.src = src;
    });
  }

  async function downloadDataUrl(dataUrl, name) {
    const format = outputFormat();
    let output = dataUrl;
    if (format.mime === "image/jpeg" && !dataUrl.startsWith("data:image/jpeg")) {
      const img = await loadImage(dataUrl);
      const canvas = document.createElement("canvas");
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext("2d");
      ctx.fillStyle = "#fff";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0);
      output = canvas.toDataURL(format.mime, 0.94);
    }
    const response = await send({ type: "DOWNLOAD_DATA_URL", dataUrl: output, filename: `${name}-${timestamp()}.${format.extension}` });
    if (!response.ok) throw new Error(response.error || "Fotografija se nije mogla sačuvati.");
  }

  async function downloadCanvas(canvas, name) {
    const format = outputFormat();
    const response = await send({ type: "DOWNLOAD_DATA_URL", dataUrl: canvasToImage(canvas), filename: `${name}-${timestamp()}.${format.extension}` });
    if (!response.ok) throw new Error(response.error || "Fotografija se nije mogla sačuvati.");
  }

  async function captureViewport() {
    if (captureBusy) return;
    setBusy(true);
    try {
      const image = await whileControlsHidden(takeScreenshot);
      await downloadDataUrl(image, "facebook-vidljivi-prozor");
    } catch (error) { showError(error); }
    finally { setBusy(false); }
  }

  function selectRegion(mode) {
    if (selecting || captureBusy) return;
    selecting = true;
    overlay = document.createElement("div");
    overlay.id = "fbms-select-overlay";
    document.documentElement.appendChild(overlay);
    const tip = document.createElement("div");
    tip.id = "fbms-tip";
    tip.textContent = mode === "top" ? "Označi GORNJI dio objave (Esc = odustani)" :
                      mode === "bottom" ? "Označi DONJI dio objave (Esc = odustani)" :
                      "Označi dio koji želiš sačuvati (Esc = odustani)";
    document.documentElement.appendChild(tip);

    let localStart = null;
    let selectionDone = false;
    let onMove = null;
    let onUp = null;
    const onDown = e => {
      if (localStart) return;
      e.preventDefault();
      localStart = { x: e.clientX, y: e.clientY };
      box = document.createElement("div");
      box.id = "fbms-select-box";
      document.documentElement.appendChild(box);
      onMove = ev => {
        const x = Math.min(localStart.x, ev.clientX), y = Math.min(localStart.y, ev.clientY);
        Object.assign(box.style, {left:x + "px",top:y + "px",width:Math.abs(ev.clientX - localStart.x) + "px",height:Math.abs(ev.clientY - localStart.y) + "px"});
      };
      onUp = async ev => {
        if (selectionDone) return;
        selectionDone = true;
        const rect = {
          x: Math.min(localStart.x, ev.clientX), y: Math.min(localStart.y, ev.clientY),
          width: Math.abs(ev.clientX - localStart.x), height: Math.abs(ev.clientY - localStart.y)
        };
        if (rect.width < 40 || rect.height < 40) { cleanup(); return; }
        setBusy(true);
        try { await captureRegion(rect, mode); }
        catch (error) { showError(error); }
        finally { cleanup(); setBusy(false); }
      };
      overlay.addEventListener("mousemove", onMove);
      overlay.addEventListener("mouseup", onUp);
    };
    const onKey = e => {
      if (e.key === "Escape") { e.preventDefault(); cleanup(); }
    };
    function cleanup() {
      selecting = false;
      overlay?.removeEventListener("mousedown", onDown);
      if (onMove) overlay?.removeEventListener("mousemove", onMove);
      if (onUp) overlay?.removeEventListener("mouseup", onUp);
      window.removeEventListener("keydown", onKey, true);
      overlay?.remove(); box?.remove(); tip.remove();
      overlay = null; box = null;
    }
    overlay.addEventListener("mousedown", onDown);
    window.addEventListener("keydown", onKey, true);
  }

  async function cropDataUrl(dataUrl, rect) {
    const img = await loadImage(dataUrl);
    const scaleX = img.width / window.innerWidth;
    const scaleY = img.height / window.innerHeight;
    const sx = Math.max(0, Math.round(rect.x * scaleX));
    const sy = Math.max(0, Math.round(rect.y * scaleY));
    const sw = Math.min(img.width - sx, Math.round(rect.width * scaleX));
    const sh = Math.min(img.height - sy, Math.round(rect.height * scaleY));
    if (sw <= 0 || sh <= 0) throw new Error("Odabrano područje je izvan ekrana.");
    const canvas = document.createElement("canvas");
    canvas.width = sw;
    canvas.height = sh;
    canvas.getContext("2d").drawImage(img, sx, sy, sw, sh, 0, 0, sw, sh);
    return { dataUrl: canvas.toDataURL("image/png"), w: sw, h: sh };
  }

  async function captureRegion(rect, mode) {
    const image = await whileControlsHidden(takeScreenshot);
    const cropped = await cropDataUrl(image, rect);
    if (mode === "single") await downloadDataUrl(cropped.dataUrl, "facebook-crop");
    else { parts[mode] = cropped; updateStatus(); }
  }

  async function joinParts() {
    if (captureBusy) return;
    if (!parts.top || !parts.bottom) {
      showError("Prvo sačuvaj i gornji i donji dio.");
      return;
    }
    setBusy(true);
    try {
      const [a, b] = await Promise.all([loadImage(parts.top.dataUrl), loadImage(parts.bottom.dataUrl)]);
      const targetWidth = Math.max(a.width, b.width);
      const aHeight = Math.round(a.height * targetWidth / a.width);
      const bHeight = Math.round(b.height * targetWidth / b.width);
      const canvas = document.createElement("canvas");
      canvas.width = targetWidth;
      canvas.height = aHeight + gapPx + bHeight;
      const ctx = canvas.getContext("2d");
      ctx.fillStyle = "#fff";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(a, 0, 0, targetWidth, aHeight);
      ctx.drawImage(b, 0, aHeight + gapPx, targetWidth, bHeight);
      await downloadCanvas(canvas, "facebook-spojeno");
    } catch (error) { showError(error); }
    finally { setBusy(false); }
  }

  // Facebook uses several DOM layouts (feed, permalink, photo dialog and
  // compact mobile). Many permalink layouts have NO role="article". Identify
  // semantic containers first, then infer the card from its visual boundaries.
  const POST_CONTAINER_SELECTOR = [
    'article', '[role="article"]',
    '[data-pagelet^="FeedUnit"]', '[data-pagelet^="ProfileTimelineFeedUnit"]',
    '[data-pagelet*="FeedUnit_"]', '[data-testid="fbfeed_story"]',
    '[data-testid="post_container"]', '[data-ft*="top_level_post_id"]'
  ].join(',');
  const PERMALINK_PATTERN = /\/(?:posts|permalink|story|videos|reel|share\/p|groups\/[^/]+\/posts)\/|[?&]story_fbid=/i;

  function rectIsPostSized(node) {
    if (!(node instanceof Element)) return false;
    const r = node.getBoundingClientRect();
    return r.width >= Math.min(180, window.innerWidth * .58) && r.height >= 100 &&
      r.width <= window.innerWidth + 50 && r.height < 50000 &&
      r.right > 0 && r.left < window.innerWidth && r.bottom > 0 && r.top < window.innerHeight;
  }

  // Exclude the page, feed and dialog scaffolding; those can contain multiple
  // posts and should never be saved as though they were one post.
  function isLayoutContainer(node) {
    return node.matches('html, body, main, [role="main"], [role="feed"], [role="dialog"], [role="navigation"], [role="complementary"]') ||
      /^(?:mount_|root$)/i.test(node.id || '') ||
      (node.getAttribute('data-pagelet') || '') === 'MainFeed';
  }

  function contentSignals(node) {
    // querySelector limits avoid expensive innerText extraction from large feeds.
    const links = node.querySelectorAll('a[href]');
    let permalink = false, timestamp = false;
    for (let i = 0; i < Math.min(links.length, 70); i++) {
      const a = links[i], href = a.getAttribute('href') || '';
      if (PERMALINK_PATTERN.test(href)) permalink = true;
      if (a.querySelector('abbr, time') || a.getAttribute('aria-label')?.match(/\b(?:ago|hour|hours|minute|minutes|day|days)\b|prije|sati|minut|dan|dana/i)) timestamp = true;
    }
    const actions = !!node.querySelector('[aria-label*="Like"], [aria-label*="Comment"], [aria-label*="Share"], [aria-label*="Sviđa"], [aria-label*="Koment"], [aria-label*="Podijeli"], [data-testid*="reaction"]');
    return { permalink, timestamp, actions };
  }

  function containsOtherPost(candidate, branch) {
    // An ancestor holding a second explicitly identified post cannot be the
    // selected card. For unmarked feeds, check for another large sibling card.
    const markedPosts = candidate.querySelectorAll(POST_CONTAINER_SELECTOR);
    let different = 0;
    for (let i = 0; i < Math.min(markedPosts.length, 10); i++) {
      if (!markedPosts[i].contains(branch)) different++;
    }
    if (different) return true;
    for (const sibling of candidate.children) {
      if (sibling.contains(branch)) continue;
      const r = sibling.getBoundingClientRect();
      if (r.width < 180 || r.height < 200) continue;
      const signals = contentSignals(sibling);
      if (signals.permalink && (signals.actions || signals.timestamp)) return true;
    }
    return false;
  }

  function postCandidates(element) {
    if (!(element instanceof Element)) return [];
    if (element.closest('#fbms-toolbar, #fbms-tip, #fbms-post-highlight, #fbms-select-overlay, #fbms-restore')) return [];
    const ancestors = [];
    for (let n = element, i = 0; n && i < 45; n = n.parentElement, i++) {
      if (n === document.body || n === document.documentElement) break;
      ancestors.push(n);
    }

    // Strong identifiers beat guessing. Prefer the highest container still
    // within the single post, not an entire feed or Facebook dialog.
    const marked = ancestors.filter(n => n.matches(POST_CONTAINER_SELECTOR) && rectIsPostSized(n) && !isLayoutContainer(n));
    if (marked.length) {
      const chosen = [...marked].reverse().find(n => !containsOtherPost(n, element)) || marked[0];
      return [chosen, ...ancestors.filter(n => rectIsPostSized(n) && !isLayoutContainer(n) && n !== chosen)];
    }

    // No markers: find the visual card enclosing the click. Track ancestors
    // until the post's width expands into a feed/dialog column or additional
    // independent posts appear. This works on newer Facebook permalink pages.
    const sized = ancestors.filter(n => rectIsPostSized(n) && !isLayoutContainer(n));
    if (!sized.length) {
      // Last fallback for single-post pages: a real main content region can
      // contain the post even if Facebook supplies no article/card wrapper.
      if (PERMALINK_PATTERN.test(location.href)) {
        const main = ancestors.find(n => n.matches('main, [role="main"]') && rectIsPostSized(n));
        if (main) return [main];
      }
      return [];
    }

    let chosenIndex = -1;
    for (let i = 0; i < sized.length; i++) {
      const n = sized[i], r = n.getBoundingClientRect();
      if (i > 0) {
        const prior = sized[i - 1], p = prior.getBoundingClientRect();
        // Do not climb into a sidebar+feed layout, or into a multi-post list.
        if (r.width > p.width + Math.max(110, p.width * .24) && p.height >= 120) break;
        // The scrolling dialog itself is a viewport, not the post content.
        const css = getComputedStyle(n);
        if (/(auto|scroll)/.test(css.overflowY) && n.scrollHeight > n.clientHeight + 5) break;
        if (containsOtherPost(n, prior)) break;
      }
      chosenIndex = i;
    }
    if (chosenIndex < 0) return [];
    const chosen = sized[chosenIndex];
    // If the chosen wrapper is just a paragraph inside a longer card, prefer
    // a sibling-free container with at least some post identifying structure.
    const others = sized.slice(0, chosenIndex + 1).reverse();
    // A small inner text block should not be offered as a complete post.
    const ordered = [chosen, ...others.filter(n => n !== chosen && n.getBoundingClientRect().height >= 170)];
    return ordered;
  }

  function findPost(element) {
    return postCandidates(element)[0] || null;
  }

  function choosePost() {
    if (pickingPost || captureBusy) return;
    pickingPost = true;
    const tip = document.createElement('div');
    tip.id = 'fbms-tip';
    tip.textContent = 'Plavi okvir = snimak · ↑/↓ promijeni okvir · klik za snimanje · Esc';
    document.documentElement.appendChild(tip);
    const highlight = document.createElement('div');
    highlight.id = 'fbms-post-highlight';
    highlight.style.display = 'none';
    document.documentElement.appendChild(highlight);
    let current = null;
    let lastBase = null;
    let candidates = [];
    let candidateIndex = 0;
    function drawHighlight(post) {
      if (!post) { highlight.style.display = 'none'; return; }
      const r = post.getBoundingClientRect();
      const top = Math.max(r.top, 0), bottom = Math.min(r.bottom, window.innerHeight);
      if (bottom <= top || r.right <= 0 || r.left >= innerWidth) { highlight.style.display = 'none'; return; }
      Object.assign(highlight.style, {
        display: 'block', left: `${Math.max(0, r.left)}px`, top: `${top}px`,
        width: `${Math.min(innerWidth, r.right) - Math.max(0, r.left)}px`,
        height: `${bottom - top}px`
      });
    }
    const onMove = e => {
      if (toolbar?.contains(e.target) || e.target === tip || e.target === highlight) return;
      const next = postCandidates(e.target);
      if (next[0] !== lastBase) candidateIndex = 0;
      lastBase = next[0] || null;
      candidates = next;
      current = candidates[candidateIndex] || next[0] || null;
      drawHighlight(current);
    };
    const onKey = e => {
      if (e.key === 'Escape') { e.preventDefault(); cleanup(); return; }
      // If a Facebook layout is unusual, let the user correct the proposed
      // post boundary before capturing (↑ larger enclosing node / ↓ smaller).
      if ((e.key === 'ArrowUp' || e.key === 'ArrowDown') && candidates.length > 1) {
        e.preventDefault();
        candidateIndex = Math.max(0, Math.min(candidates.length - 1, candidateIndex + (e.key === 'ArrowUp' ? 1 : -1)));
        current = candidates[candidateIndex];
        drawHighlight(current);
      }
    };
    const onClick = e => {
      if (toolbar?.contains(e.target)) return;
      const next = postCandidates(e.target);
      const post = current && current.contains(e.target) ? current : next[0] || null;
      e.preventDefault();
      e.stopImmediatePropagation();
      cleanup();
      if (!post) {
        showError('Nije moguće odrediti granice objave u ovom Facebook prikazu. Otvori objavu preko njenog datuma/vremena i ponovo pokušaj, ili koristi „Jedan crop“.');
        return;
      }
      captureFullPost(post);
    };
    function cleanup() {
      document.removeEventListener('mousemove', onMove, true);
      document.removeEventListener('click', onClick, true);
      window.removeEventListener('keydown', onKey, true);
      highlight.remove(); tip.remove();
      pickingPost = false;
    }
    document.addEventListener('mousemove', onMove, true);
    document.addEventListener('click', onClick, true);
    window.addEventListener('keydown', onKey, true);
  }

  // Detect scrollable Facebook dialogs as well as ordinary page scroll. Do not
  // scroll the feed when the post is inside an independently scrolling dialog.
  function scrollContainer(post) {
    for (let node = post.parentElement; node && node !== document.documentElement; node = node.parentElement) {
      const css = getComputedStyle(node);
      if (/(auto|scroll)/.test(css.overflowY) && node.scrollHeight > node.clientHeight + 5 && node.clientHeight > 150) return node;
    }
    return null; // null means window/document scrolling
  }

  function getScrollTop(scroller) {
    return scroller ? scroller.scrollTop : window.scrollY;
  }

  function setScrollTop(scroller, value) {
    if (scroller) scroller.scrollTo({ top: value, behavior: "instant" });
    else window.scrollTo({ top: value, behavior: "instant" });
  }

  function scrollerViewport(scroller) {
    if (!scroller) return { top: 0, bottom: window.innerHeight, left: 0, right: window.innerWidth };
    const rect = scroller.getBoundingClientRect();
    return {
      top: Math.max(0, rect.top), bottom: Math.min(window.innerHeight, rect.bottom),
      left: Math.max(0, rect.left), right: Math.min(window.innerWidth, rect.right)
    };
  }

  async function captureFullPost(post) {
    if (captureBusy) return;
    setBusy(true);
    const scroller = scrollContainer(post);
    const originalScroll = getScrollTop(scroller);
    try {
      if (!post.isConnected) throw new Error("Objava više nije prikazana na stranici.");
      // Place the start of the article below Facebook's fixed top navigation.
      // This padding affects how we scroll, not the saved image's contents.
      const topPadding = scroller ? 0 : 64;
      let bounds = scrollerViewport(scroller);
      const initialRect = post.getBoundingClientRect();
      setScrollTop(scroller, originalScroll + initialRect.top - bounds.top - topPadding);
      await pause(460); // allow Facebook images to load and layout to settle

      let rect = post.getBoundingClientRect();
      bounds = scrollerViewport(scroller);
      let articleHeight = Math.ceil(rect.height);
      const left = Math.max(0, bounds.left, rect.left);
      const right = Math.min(window.innerWidth, bounds.right, rect.right);
      const width = right - left;
      if (width < 100 || articleHeight < 60) throw new Error("Objava nije dovoljno vidljiva za automatsko snimanje.");

      let done = 0;
      let canvas = null;
      let ctx = null;
      let scaleX = 1, scaleY = 1;
      let iterations = 0;
      const maxIterations = 80;
      while (done < articleHeight - 0.5) {
        if (!post.isConnected) throw new Error("Facebook je tokom skrolanja uklonio objavu iz prikaza. Koristi ručni crop ili dva dijela.");
        bounds = scrollerViewport(scroller);
        rect = post.getBoundingClientRect();
        const safeTop = Math.min(bounds.bottom - 10, bounds.top + topPadding);
        const wanted = getScrollTop(scroller) + rect.top + done - safeTop;
        setScrollTop(scroller, wanted);
        await pause(360); // lazy-loaded photos and stable post layout

        rect = post.getBoundingClientRect();
        bounds = scrollerViewport(scroller);
        // Do not include any area that is clipped by a nested scroll container.
        const clipTop = Math.max(bounds.top + topPadding, 0);
        const clipBottom = Math.min(bounds.bottom, window.innerHeight);
        const visibleStart = Math.max(done, Math.max(0, clipTop - rect.top));
        const visibleEnd = Math.min(articleHeight, rect.height, clipBottom - rect.top);
        if (visibleStart > done + 2) throw new Error("Dio objave nije moguće prikazati tokom automatskog skrolanja. Pokušaj smanjiti zoom ili koristi dva cropa.");
        if (visibleEnd <= visibleStart + 1) throw new Error("Objava se ne može dalje skrolati. Pokušaj proširiti prozor ili koristi dva cropa.");

        const image = await whileControlsHidden(takeScreenshot);
        const img = await loadImage(image);
        if (!canvas) {
          scaleX = img.width / window.innerWidth;
          scaleY = img.height / window.innerHeight;
          const pixelWidth = Math.round(width * scaleX);
          const pixelHeight = Math.round(articleHeight * scaleY);
          // Prevent huge browser canvases and misleading partial images.
          if (pixelWidth > 6000 || pixelHeight > 24000 || pixelWidth * pixelHeight > 36000000)
            throw new Error("Objava je prevelika za jednu fotografiju. Koristi Gornji/Donji dio ili smanji zoom.");
          canvas = document.createElement("canvas");
          canvas.width = pixelWidth;
          canvas.height = pixelHeight;
          ctx = canvas.getContext("2d");
          if (!ctx) throw new Error("Nema dovoljno memorije za fotografiju ove veličine.");
          ctx.fillStyle = "#fff";
          ctx.fillRect(0, 0, canvas.width, canvas.height);
        }
        const sy = Math.round((rect.top + visibleStart) * scaleY);
        const sh = Math.min(img.height - sy, Math.round((visibleEnd - visibleStart) * scaleY));
        const sx = Math.round(left * scaleX);
        const sw = Math.min(img.width - sx, Math.round(width * scaleX));
        if (sw <= 0 || sh <= 0) throw new Error("Dio objave nalazi se izvan vidljivog prozora.");
        const dy = Math.round(visibleStart * scaleY);
        const dh = Math.min(canvas.height - dy, Math.round((visibleEnd - visibleStart) * scaleY));
        ctx.drawImage(img, sx, sy, sw, sh, 0, dy, canvas.width, dh);
        done = visibleEnd;
        if (++iterations > maxIterations) throw new Error("Objava je preduga za automatsko snimanje.");
      }
      await downloadCanvas(canvas, "facebook-cijela-objava");
    } catch (error) { showError(error); }
    finally {
      // Return the post to the position where the user was reading it.
      setScrollTop(scroller, originalScroll);
      setBusy(false);
    }
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "FBMS_ACTIVATE") { makeToolbar(); sendResponse({ ok: true }); }
  });
})();
