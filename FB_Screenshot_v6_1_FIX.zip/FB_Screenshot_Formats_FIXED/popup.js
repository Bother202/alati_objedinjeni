
const urlEl = document.getElementById("url");
const widthEl = document.getElementById("width");
const heightEl = document.getElementById("height");
const formatEl = document.getElementById("format");
const msg = document.getElementById("msg");
const detectedBox = document.getElementById("detectedBox");
const detectedTitle = document.getElementById("detectedTitle");
const detectedUrl = document.getElementById("detectedUrl");
const notDetected = document.getElementById("notDetected");
const openDetected = document.getElementById("openDetected");

let currentFacebookTab = null;

function isFacebookUrl(u) {
  try {
    const x = new URL(u);
    return x.hostname === "facebook.com" || x.hostname.endsWith(".facebook.com");
  } catch { return false; }
}

function send(obj){
  return new Promise(resolve => chrome.runtime.sendMessage(obj, resolve));
}


const FORMATS = {
  mobile: { width: 430, height: 920 },
  tablet: { width: 768, height: 1024 },
  desktop: { width: 1200, height: 900 }
};

function applyFormat(name) {
  const f = FORMATS[name];
  if (!f) return;
  widthEl.value = String(f.width);
  heightEl.value = String(f.height);
  chrome.storage.local.set({
    fbms_format: name,
    fbms_width: widthEl.value,
    fbms_height: heightEl.value
  });
}

function settings() {
  const width = Number.parseInt(widthEl.value, 10);
  const height = Number.parseInt(heightEl.value, 10);

  return {
    width: Number.isFinite(width) && width >= 320 ? width : 430,
    height: Number.isFinite(height) && height >= 400 ? height : 920
  };
}

async function openUrl(url) {
  msg.textContent = "";
  if (!isFacebookUrl(url)) {
    msg.textContent = "Unesi ispravan Facebook link.";
    return;
  }
  const s = settings();
  const res = await send({
    type: "OPEN_MOBILE",
    url,
    width: s.width,
    height: s.height
  });
  if (!res?.ok) msg.textContent = res?.error || "Nije moguće otvoriti objavu.";
  else window.close();
}

async function detectCurrentTab() {
  try {
    const tabs = await chrome.tabs.query({active:true,currentWindow:true});
    const tab = tabs[0];
    if (tab && isFacebookUrl(tab.url || "")) {
      currentFacebookTab = tab;
      detectedTitle.textContent = tab.title || "Facebook";
      detectedUrl.textContent = tab.url;
      detectedBox.classList.remove("hidden");
      notDetected.classList.add("hidden");

      // Convenience: also prefill manual field, but user can overwrite it.
      urlEl.value = tab.url;
    } else {
      currentFacebookTab = null;
      detectedBox.classList.add("hidden");
      notDetected.classList.remove("hidden");
    }
  } catch {
    detectedBox.classList.add("hidden");
    notDetected.classList.remove("hidden");
  }
}

openDetected.addEventListener("click", async () => {
  if (!currentFacebookTab?.url) return;
  await openUrl(currentFacebookTab.url);
});

document.getElementById("open").addEventListener("click", () => {
  openUrl(urlEl.value.trim());
});

// Save preferred screenshot dimensions.
formatEl.addEventListener("change", () => {
  if (formatEl.value !== "custom") applyFormat(formatEl.value);
  else chrome.storage.local.set({ fbms_format: "custom" });
});

for (const el of [widthEl, heightEl]) {
  el.addEventListener("change", () => {
    formatEl.value = "custom";
    chrome.storage.local.set({
      fbms_format: "custom",
      fbms_width: widthEl.value,
      fbms_height: heightEl.value
    });
  });
}

chrome.storage.local.get(["fbms_format","fbms_width","fbms_height"], data => {
  const savedFormat = data.fbms_format;

  // Presets always re-apply their real dimensions. This also repairs values
  // saved by older versions where 768/1200 px could not exist in the dropdown.
  if (savedFormat && FORMATS[savedFormat]) {
    formatEl.value = savedFormat;
    applyFormat(savedFormat);
    return;
  }

  if (savedFormat === "custom") {
    formatEl.value = "custom";
    if (data.fbms_width) widthEl.value = data.fbms_width;
    if (data.fbms_height) heightEl.value = data.fbms_height;
    return;
  }

  applyFormat("mobile");
});

detectCurrentTab();
